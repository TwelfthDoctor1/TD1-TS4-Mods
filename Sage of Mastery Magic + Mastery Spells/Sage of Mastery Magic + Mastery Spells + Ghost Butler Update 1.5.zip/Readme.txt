MOD INSTALL INSTRUCTIONS

* Make sure that .package files are placed in your Mods folder, no more than one folder deep
* [OVERRIDE MODS] They must be places in Mods/Overrides folder.

IMPORTANT

* If you have Zero's Vampire Witches mod, you MUST put the MagicHQZoneDirectorTuning.package in the Overrides folder. Otherwise, the Vampire Sage and/or Mastery Sage will not appear.

