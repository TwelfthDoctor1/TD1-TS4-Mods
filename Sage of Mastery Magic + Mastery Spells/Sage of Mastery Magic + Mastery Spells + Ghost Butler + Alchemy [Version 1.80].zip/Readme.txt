MOD INSTALL INSTRUCTIONS

* Make sure that .package files are placed in your Mods folder, no more than one folder deep.
* [OVERRIDE MODS] They must be placed in Mods/Overrides folder.


IMPORTANT

* If you have Zero's Vampire Witches mod, you MUST put the MagicHQZoneDirectorTuning.package in the Overrides folder. Otherwise, the Vampire Sage and/or Mastery Sage will not appear.
* If you have Zero's VampirePotions mod, you MUST put the TD1 Alchemy + VampirePotions.package in the Overrides folder. Otherwise, the Cauldron VFXes will not appear.

.packages that MUST be removed due to conflictions (All .packages listed here do not have [Mastery Spells] Tag):

* RoM Mermaidic Transformation Spell.package
* RoM Vampiric Transformation Spell.package
* RoM Occult Transformation Spells.package
* RoM Spellcurses Sageproof.package [Version 1]
* RoM Spellcurses.package [Version 1]